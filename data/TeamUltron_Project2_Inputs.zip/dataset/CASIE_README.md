# CASIE Cybersecurity Event Argument Extraction Dataset

## Project Overview

This dataset supports cybersecurity event argument extraction.

The objective is to identify the roles of entities and
information associated with specific cybersecurity incidents.

Unlike basic named entity recognition, the model must identify
which arguments belong to a particular event.

## Dataset Summary

- Documents: 999
- Event mentions: 8,482
- Argument records: 22,694
- Event subtypes: 5
- Argument roles: 26

## Dataset Splits

| Split | Documents | Events | Arguments |
|---|---:|---:|---:|
| Training | 799 | 6,877 | 18,445 |
| Validation | 100 | 869 | 2,140 |
| Test | 100 | 736 | 2,109 |

Splitting was performed at document level using random seed 42.

All events belonging to the same document remain in the same
split.

Known near-duplicate documents were grouped together.

## Main Files

CASIE_train.jsonl
    Training data.

CASIE_validation.jsonl
    Validation data.

CASIE_test.jsonl
    Held-out test data.

CASIE_event_records.jsonl
    Cleaned event records with original annotation information.

CASIE_document_split_manifest.csv
    Document-to-split assignments.

CASIE_split_constraints.csv
    Known near-duplicate grouping constraints.

CASIE_dataset_metadata.json
    Dataset metadata and preprocessing limitations.

CASIE_dataset_checksums.csv
    SHA-256 hashes for dataset verification.

## Record Structure

Each model-ready JSONL line represents one cybersecurity event.

Important fields:

document_id
    Original CASIE document identifier.

event_uid
    Unique event identifier.

event_type
    General cybersecurity event category.

event_subtype
    Specific event subtype.

trigger
    Event trigger annotation and token positions.

tokens
    Tokenized document text.

token_offsets
    Character offsets of each token.

token_labels
    Event-conditioned BIO labels.
    Each token contains a list of labels.

role_layers
    Separate BIO sequence for each argument role.

arguments
    Original argument information and aligned token IDs.

## Tokenization Policy

Tokenization is performed using document text only.

The tokenizer uses a Unicode-aware regular expression:

    \w+|[^\w\s]

Ground-truth annotation boundaries are NOT used to split tokens.

This ensures the same tokenization procedure can be applied
to previously unseen cybersecurity reports.

Total document tokens: 448,434

Total annotations checked: 31,176

Exactly aligned annotations: 31,151

Partial-token annotations: 25

All annotations were mapped to overlapping tokens.

Original character offsets are preserved.

For the 25 partial-token cases, BIO labels represent the
overlapping tokens rather than exact character boundaries.

## BIO Labeling

B-ROLE:
    Beginning of an argument span.

I-ROLE:
    Inside an argument span.

O:
    Outside an argument span.

Labels are generated separately for each event.

The same document may therefore appear in multiple event
records with different argument labels.

Some tokens have multiple simultaneous argument roles.

Do not collapse multi-label annotations into one arbitrary
label.

## Cleaning Summary

1. Validated original CASIE annotation structure.
2. Identified and resolved 1,095 character-offset issues.
3. Applied 1,094 verified offset corrections.
4. Resolved one additional annotation manually.
5. Removed one exact duplicate document.
6. Preserved a near-duplicate pair in the same split.
7. Removed one repeated identical argument record.
8. Preserved legitimate multi-role annotations.
9. Applied text-only tokenization.
10. Preserved all original token boundaries.
11. Mapped annotations to overlapping tokens.
12. Documented 25 partial-token alignment cases.
13. Handled trailing non-breaking spaces during alignment.
14. Generated event-conditioned multilabel BIO labels.
15. Validated event records and argument representations.
16. Created document-level train/validation/test splits.
17. Verified dataset integrity and leakage constraints.

## Validation

- All 8,482 event records validated.
- All 22,694 argument records represented.
- All 31,176 annotations mapped to tokens.
- No invalid BIO event records.
- No detected document overlap across splits.
- Known near-duplicate grouping constraints satisfied.
- Exported split records match validated source records.

## Known Limitations

### Rare Argument Roles

Some argument roles have very few examples in the
validation and test datasets.

Damage-Amount has only 42 examples across the dataset.

Per-role evaluation results for rare categories should
be interpreted cautiously.

### Partial-Token Alignment

25 annotation occurrences do not align exactly with
text-only token boundaries.

These annotations are mapped to overlapping tokens.

Their original character offsets remain available.

Token-level BIO labels may cover slightly more text
than the original character-level annotation.

### Multi-Role Arguments

Some event-token occurrences have multiple BIO labels.

Four event-token occurrences were identified with
multiple simultaneous labels.

The dataset preserves these using multilabel token
annotations and role-specific BIO layers.

### Full-Document Token Sequences

Each event record contains the tokenized source document.

These sequences may exceed transformer context limits.

Model developers should implement an appropriate
event-centered context-window strategy.

### Evaluation

The test set should remain held out until final evaluation.

Recommended metrics include argument-level micro-F1,
macro-F1, and per-role precision, recall, and F1.

Evaluation should be based on predicted argument spans
and roles rather than token accuracy alone.

## Reproducibility

Random seed: 42

Document assignments:

CASIE_document_split_manifest.csv

Dataset checksums:

CASIE_dataset_checksums.csv

Automatic offset corrections:

CASIE_applied_corrections.csv

Final manual correction:

CASIE_final_annotation_correction.csv

Partial-token alignment audit:

CASIE_partial_token_alignment_issues.csv
